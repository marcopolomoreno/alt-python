from .letras import contar_letras
from .palavras import contar_palavras
from .silabas import contar_silabas
from .frases import contar_frases
from .palavrasComplexas import contar_palavras_complexas
